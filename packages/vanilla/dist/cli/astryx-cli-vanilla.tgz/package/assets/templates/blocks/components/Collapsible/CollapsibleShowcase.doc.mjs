// Copyright (c) Meta Platforms, Inc. and affiliates.

/** @type {import('@astryxdesign/cli/authoring').TemplateDoc} */
export const doc = {
  type: 'block',
  exampleFor: 'Collapsible',
  alsoShowcaseFor: ['useCollapsible'],
  name: 'Collapsible',
  displayName: 'Collapsible',
  description:
    'An accordion group with three collapsible sections in single mode: opening one closes the others.',
  isReady: true,
  isShowcase: true,
  aspectRatio: 16 / 9,
  componentsUsed: ['Collapsible', 'CollapsibleGroup', 'Text', 'Card', 'Stack'],
};
